// synthetic RC A fixture
